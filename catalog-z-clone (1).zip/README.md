# Catalog-Z Clone

Upload images from the reference template into an images folder and enhance styling for pixel-perfect matching.

## Run
Open index.html in browser.
